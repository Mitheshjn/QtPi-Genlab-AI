from ultralytics import YOLO
import torch

device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")

model = YOLO("best.pt")   # use pre-trained COCO weights

results = model.predict(
    source="M:\\MITH pc\\Yolo\\1.jpg",    # test folder or single image path
    conf=0.25,                       # confidence threshold
    save=True                        # save predictions with bounding boxes
)

print(results)